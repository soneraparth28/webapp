<?php /** @noinspection ALL */

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\User;
use App\Models\AdminSettings;
use App\Models\Comments;
use App\Models\CommentsLikes;
use App\Models\Notifications;
use App\Models\Updates;
use App\Helper;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Storage;

class CommentsController extends Controller
{
    public function __construct(AdminSettings $settings, Request $request)
    {
        $this->settings = $settings::first();
        $this->request = $request;
    }
    public function loadmore(Request $request)
    {
        $id       = $request->input('id');
        $postId   = $request->input('post');
        $skip     = $request->input('skip');
        $response = Updates::findOrFail($postId);
        $page  = $request->input('page');
        $comments = $response->comments()->skip($skip)->take($this->settings->number_comments_show)->orderBy('id', 'DESC')->get();
        $data = [];
        if ($comments->count()) {
            $data['reverse'] = collect($comments->values())->reverse();
        } else {
            $data['reverse'] = $comments;
        }
        $dataComments = $data['reverse'];
        $counter = ($response->comments()->count() - $this->settings->number_comments_show - $skip);
        $response = [
            'success' => true,
            'data' => [
                'dataComments' => $dataComments,
                'comments' => $comments,
                'response' => $response,
                'counter' => $counter,
            ],
            'message' => 'Comments Data.',
        ];
        return response()->json($response , 200);
//        return response()->json([
//            'comments' => view('includes.comments',
//                [
//                    'dataComments' => $dataComments,
//                    'comments' => $comments,
//                    'response' => $response,
//                    'counter' => $counter
//                ]
//            )->render()
//        ]);
    }
}
