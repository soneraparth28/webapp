<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use App\Models\AdminSettings;
use App\Models\Conversations;
use App\Models\Notifications;
use App\Models\Messages;
use App\Models\MediaMessages;
use App\Models\User;
use App\Helper;
use Carbon\Carbon;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use App\Events\MassMessagesEvent;
use App\Jobs\EncodeVideoMessages;
use Image;
use Cache;

class MessagesController extends Controller
{
    public function inbox()
    {
        $settings = AdminSettings::first();

		$messages = Conversations::has('messages')->where('user_1', auth()->user()->id)->orWhere('user_2', auth()->user()->id)->orderBy('updated_at', 'DESC')->orderBy('id', 'DESC')->paginate(10);
        if(request()->ajax()) {
            $response = [
                'success' => true,
                'data' => [
                    'messages' => $messages,
                ],
                'message' =>  'Messages Data.'
            ]; 
            return response()->json($response , 200);
            // return view('includes.messages-inbox',['messagesInbox' => $messages])->render();
        }
        $response = [
            'success' => true,
            'data' => [
                'messages' => $messages,
            ],
            'message' =>  'Messages Data.'
        ]; 
        return response()->json($response , 200);
        // return view('users.messages', ['messagesInbox' => $messages]);
	}
    public function messages($id)
    {
        $user = User::whereId($id)->where('id', '<>', auth()->user()->id)->firstOrFail();
        $allMessages = Messages::where('to_user_id', auth()->user()->id)
	        ->where('from_user_id', $id)->whereMode('active')->orWhere( 'from_user_id', auth()->user()->id )
	        ->where('to_user_id', $id)->whereMode('active')->orderBy('messages.updated_at', 'ASC')
	        ->get();
        $messages = Messages::where('to_user_id', auth()->user()->id)->where('from_user_id', $id)
            ->whereMode('active')->orWhere( 'from_user_id', auth()->user()->id )->where('to_user_id', $id)
            ->whereMode('active')->take(10)->orderBy('messages.updated_at', 'DESC')->get();
        $messagesInbox = Conversations::has('messages')
            ->where('user_1', auth()->user()->id)->orWhere('user_2', auth()->user()->id)
		    ->orderBy('updated_at', 'DESC')->orderBy('id', 'DESC')->paginate(10);
        $data = [];
        if($messages->count()) {
  	        $data['reverse'] = collect($messages->values())->reverse();
  	    } else {
  	        $data['reverse'] = $messages;
  	    }
  	    $messages = $data['reverse'];
  	    $counter = ($allMessages->count() - 10);
        // UPDATE MESSAGE 'READED'
        $messageReaded = new Messages();
        $messageReaded->timestamps = false;
        $messageReaded->newModelQuery()->where('from_user_id', $id)->where('to_user_id', auth()->user()->id)
            ->where('status', 'new')->update(['status' => 'readed']);
        // Check if subscription exists
        $subscribedToYourContent = $this->subscribedToYourContent($user);
        $subscribedToMyContent = $this->subscribedToMyContent($user);
        $response = [
            'success' => true,
            'data' => [
                'messages' => $messages,
                'messagesInbox' => $messagesInbox,
                'user' => $user,
                'counter' => $counter,
                'allMessages' => $allMessages->count(),
                'subscribedToYourContent' => $subscribedToYourContent,
                'subscribedToMyContent' => $subscribedToMyContent,
            ],
            'message' =>  'Messages Data.'
        ]; 
        return response()->json($response , 200);
		// return view('users.messages-show', [
        //     'messages' => $messages,
        //     'messagesInbox' => $messagesInbox,
        //     'user' => $user,
        //     'counter' => $counter,
        //     'allMessages' => $allMessages->count(),
        //     'subscribedToYourContent' => $subscribedToYourContent,
        //     'subscribedToMyContent' => $subscribedToMyContent
        // ]);
	}
    public function loadmore(Request $request)
	{
	    $id   = $request->input('id');
		$skip = $request->input('skip');
        $user = User::whereId($id)->where('id', '<>', auth()->user()->id)->firstOrFail();
        $allMessages = Messages::where('to_user_id', auth()->user()->id)->where('from_user_id', $id)
            ->whereMode('active')->orWhere( 'from_user_id', auth()->user()->id)->where('to_user_id', $id)
            ->whereMode('active')->orderBy('messages.id', 'ASC')->get();
        $messages = Messages::where('to_user_id', auth()->user()->id)
			->where('from_user_id', $id)->whereMode('active')->orWhere( 'from_user_id', auth()->user()->id )
			->where('to_user_id', $id)->whereMode('active')->skip($skip)->take(10)
			->orderBy('messages.id', 'DESC')->get();
  	    $data = [];
  	    if($messages->count()) {
            $data['reverse'] = collect($messages->values())->reverse();
  	    } else {
  	        $data['reverse'] = $messages;
  	    }
  	    $messages = $data['reverse'];
  		$counter = ($allMessages->count() - 10 - $skip);
        $response = [
            'success' => true,
            'data' => [
                'messages' => $messages,
                'user' => $user,
                'counter' => $counter,
                'allMessages' => $allMessages->count(),
            ],
            'message' =>  'Messages Data.'
        ]; 
        return response()->json($response , 200);
        // return view('includes.messages-chat', [
        //     'messages' => $messages,
        //     'user' => $user,
        //     'counter' => $counter,
        //     'allMessages' => $allMessages->count()
        // ])->render();
	}
    public function ajaxChat(Request $request)
    {
        if(! auth()->check()) {
            $response = [
                'success' => true,
                'data' => [
                    'session_null' => true,
                ],
                'message' =>  'Messages Data.'
            ]; 
            return response()->json($response , 400);
            // return response()->json(['session_null' => true]);
        }
        $_sql = $request->get('first_msg') == 'true' ? '=' : '>';
        $message = Messages::where('to_user_id', auth()->user()->id)
            ->where('from_user_id', $request->get('user_id'))->where('id' , $request->get('last_id'))
            ->whereMode('active')->orWhere('from_user_id', auth()->user()->id )
            ->where('to_user_id', $request->get('user_id'))->where('id', $request->get('last_id'))
            ->whereMode('active')->orderBy('messages.id', 'ASC')->get();
        $count = $message->count();
        $_array = array();
        if($count != 0) {
            foreach($message as $msg) {
            // UPDATE HOW READ MESSAGE
                if($msg->to_user_id == auth()->user()->id) {
                    $readed = Messages::where('id', $msg->id)->where('to_user_id', auth()->user()->id)
                    ->where('status', 'new')->update(['status' => 'readed'], ['updated_at' => false]);
                }
                $_array[] = view('includes.messages-chat', [
       			        'messages' => $message,
       			        'allMessages' => 0,
       			        'counter' => 0
       			    ])->render();
            }//<--- foreach
        }//<--- IF != 0
        $user = User::findOrFail($request->get('user_id'));
        if($user->active_status_online == 'yes') {
            // Check User Online
            if(Cache::has('is-online-' . $request->get('user_id'))) {
                $userOnlineStatus = true;
            } else {
                $userOnlineStatus = false;
            }
        } else {
            $userOnlineStatus = null;
        }
        $response = [
            'success' => true,
            'data' => [
                'total'    => $count,
            'messages' => $_array,
            'success' => true,
            'to' => $request->get('user_id'),
            'userOnline' => $userOnlineStatus,
            'last_seen' => date('c', strtotime($user->last_seen ?? $user->date)),
            ],
            'message' =>  'Messages Data.'
        ]; 
        return response()->json($response , 200);
        // return response()->json(array(
        //     'total'    => $count,
        //     'messages' => $_array,
        //     'success' => true,
        //     'to' => $request->get('user_id'),
        //     'userOnline' => $userOnlineStatus,
        //     'last_seen' => date('c', strtotime($user->last_seen ?? $user->date))
        //     ), 200);
    }
    public function loadAjaxChat($id)
    {
        if(! request()->ajax()) {
            $response = [
                'success' => false,
                'data' => null,
                'message' =>  'Error Occured.'
            ]; 
            return response()->json($response , 401);
            // abort(401);
        }
        $user = User::whereId($id)->where('id', '<>', auth()->user()->id)->firstOrFail();
 		$allMessages = Messages::where('to_user_id', auth()->user()->id)->where('from_user_id', $id)
            ->whereMode('active')->orWhere( 'from_user_id', auth()->user()->id )
 		    ->where('to_user_id', $id)->whereMode('active')
 		    ->orderBy('messages.id', 'ASC')->get();
 		$messages = Messages::where('to_user_id', auth()->user()->id)->where('from_user_id', $id)
            ->whereMode('active')->orWhere( 'from_user_id', auth()->user()->id )
 		    ->where('to_user_id', $id)->whereMode('active')->take(10)
 		    ->orderBy('messages.id', 'DESC')->get();
 		$data = [];
 		if($messages->count()) {
 			$data['reverse'] = collect($messages->values())->reverse();
 		} else {
 			$data['reverse'] = $messages;
 		}
 		$messages = $data['reverse'];
 		$counter = ($allMessages->count() - 10);
        $response = [
            'success' => true,
            'data' => [
                'messages' => $messages,
 			    'user' => $user,
 			    'allMessages' => $allMessages->count(),
 			    'counter' => $counter,
            ],
            'message' =>  'Messages Data.'
        ]; 
        return response()->json($response , 200);
 		// return view('includes.messages-chat', [
 		// 	'messages' => $messages,
 		// 	'user' => $user,
 		// 	'allMessages' => $allMessages->count(),
 		// 	'counter' => $counter
 		// ])->render();
    }
    public function downloadFileZip($id)
    {
        $msg = Messages::findOrFail($id);
        if($msg->to_user_id != auth()->user()->id && $msg->from_user_id != auth()->user()->id) {
            $response = [
                'success' => false,
                'data' => null,
                'message' =>  'Error Occured.'
            ]; 
            return response()->json($response , 404);
            // abort(404);
        }
        $media = MediaMessages::whereMessagesId($msg->id)->where('type', 'zip')->firstOrFail();
        $pathFile = config('path.messages').$media->file;
        $headers = [
            'Content-Type:' => 'application/x-zip-compressed',
            'Cache-Control' => 'no-cache, no-store, must-revalidate',
            'Pragma' => 'no-cache',
            'Expires' => '0'
        ];
        $response = [
            'success' => true,
            'data' => [
                'header' => $headers,
 			    'file_path' => $pathFile,
                'file_name' => $media->file_name.'.zip',
            ],
            'message' =>  'Download File Data.'
        ]; 
        return response()->json($response , 200);
        // return Storage::download($pathFile, $media->file_name.'.zip', $headers);
   }
}
