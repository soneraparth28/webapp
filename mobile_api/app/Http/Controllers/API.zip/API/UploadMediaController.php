<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Http\File;
use Illuminate\Support\Facades\Storage;
use App\Models\User;
use App\Models\Updates;
use App\Models\Messages;
use App\Models\AdminSettings;
use App\Models\Media;
use Carbon\Carbon;
use App\Helper;
use Image;
use FileUploader;

class UploadMediaController extends Controller
{
    public function __construct(AdminSettings $settings, Request $request)
    {
        $this->settings = $settings::first();
        $this->request = $request;
        $this->middleware('auth');
    }
    public function store()
    {
        $publicPath = public_path('temp/');
        $file = strtolower(auth()->id().uniqid().time().str_random(20));
        // initialize FileUploader
        $FileUploader = new FileUploader('photo', array(
            'limit' => $this->settings->maximum_files_post,
            'fileMaxSize' => floor($this->settings->file_size_allowed / 1024),
            'extensions' => [
                'png',
                'jpeg',
                'jpg',
                'gif',
                'ief',
                'video/mp4',
                'video/quicktime',
                'video/3gpp',
                'video/mpeg',
                'video/x-matroska',
                'video/x-ms-wmv',
                'video/vnd.avi',
                'video/avi',
                'video/x-flv',
                'audio/x-matroska',
                'audio/mpeg'
            ],
            'title' => $file,
            'uploadDir' => $publicPath
        ));
        // upload
        $upload = $FileUploader->upload();
        if ($upload['isSuccess']) {
            foreach($upload['files'] as $key=>$item) {
                $upload['files'][$key] = [
                    'extension' => $item['extension'],
                    'format' => $item['format'],
                    'name' => $item['name'],
                    'size' => $item['size'],
                    'size2' => $item['size2'],
                    'type' => $item['type'],
                    'uploaded' => true,
                    'replaced' => false
                ];
                switch ($item['format']) {
                    case 'image':
                        $this->resizeImage($item['name'], $item['extension']);
                        break;
                    case 'video':
                        $this->uploadVideo($item['name']);
                        break;
                    case 'audio':
                        $this->uploadMusic($item['name']);
                        break;
                }
            }// foreach
        }// upload isSuccess
        $response = [
            'success' => true,
            'data' => [
                'upload_data' => $upload,
            ],
            'message' => 'Upload Data.',
        ];
        return response()->json($response , 200);
//        return response()->json($upload);
    }
}
