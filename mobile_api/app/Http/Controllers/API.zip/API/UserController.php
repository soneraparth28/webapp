<?php /** @noinspection ALL */

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Traits\Functions;
use App\Http\Controllers\Traits\UserDelete;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use App\Models\User;
use App\Models\Subscriptions;
use App\Models\AdminSettings;
use App\Models\Withdrawals;
use App\Models\Updates;
use App\Models\Like;
use App\Models\Notifications;
use App\Models\Purchases;
use App\Models\Reports;
use App\Models\Restrictions;
use App\Models\Media;
use App\Models\TaxRates;
use App\Models\Plans;
use App\Models\PaymentGateways;
use App\Models\Transactions;
use App\Models\VerificationRequests;
use App\Models\Deposits;
use App\Models\Categories;
use App\Helper;
use Carbon\Carbon;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Notification;
use App\Notifications\AdminVerificationPending;
use App\Notifications\AdminWithdrawalPending;
use App\Models\Referrals;
use App\Models\ReferralTransactions;
use Yabacon\Paystack;
use App\Events\SubscriptionDisabledEvent;
use Image;
use DB;

class UserController extends Controller
{
    use Functions,UserDelete;
    public function __construct(Request $request, AdminSettings $settings) {
        $this->request = $request;
        $this->settings = $settings::first();
    }
    public function dashboard()
    {
        if (auth()->user()->verified_id != 'yes') {
            $response = [
                'success' => false,
                'data' => null,
                'message' => 'Error Occurred.',
            ];
            return response()->json($response , 404);
//            abort(404);
        }
        $earningNetUser = auth()->user()->myPaymentsReceived()->sum('earning_net_user');
        $subscriptionsActive = auth()->user()->totalSubscriptionsActive();
        $month = date('m');
        $year = date('Y');
        $daysMonth = Helper::daysInMonth($month, $year);
        $dateFormat = "$year-$month-";
        $monthFormat  = trans("months.$month");
        $currencySymbol = $this->settings->currency_symbol;
        for ($i=1; $i <= $daysMonth; ++$i) {
            $date = date('Y-m-d', strtotime($dateFormat.$i));
            $_subscriptions = auth()->user()->myPaymentsReceived()->whereDate('created_at', '=', $date)->sum('earning_net_user');
            $monthsData[] =  "'$monthFormat $i'";
            $_earningNetUser = $_subscriptions;
            $earningNetUserSum[] = $_earningNetUser;
        }
        // Today
        $stat_revenue_today = Transactions::where('created_at', '>=', date('Y-m-d H:i:s', strtotime('today')))
            ->whereApproved('1')->whereSubscribed(auth()->id())->sum('earning_net_user');
        // Yesterday
        $stat_revenue_yesterday = Transactions::where('created_at', '>=', Carbon::yesterday())
            ->where('created_at', '<', date('Y-m-d H:i:s', strtotime('today')))
            ->whereApproved('1')->whereSubscribed(auth()->id())->sum('earning_net_user');
        // Week
        $stat_revenue_week = Transactions::whereBetween('created_at', [
            Carbon::parse()->startOfWeek(),
            Carbon::parse()->endOfWeek(),
        ])->whereApproved('1')->whereSubscribed(auth()->id())->sum('earning_net_user');
        // Last Week
        $stat_revenue_last_week = Transactions::whereBetween('created_at', [
            Carbon::now()->startOfWeek()->subWeek(),
            Carbon::now()->subWeek()->endOfWeek(),
        ])->whereApproved('1')->whereSubscribed(auth()->id())->sum('earning_net_user');
        // Month
        $stat_revenue_month = Transactions::whereBetween('created_at', [
            Carbon::parse()->startOfMonth(),
            Carbon::parse()->endOfMonth(),
        ])->whereApproved('1')->whereSubscribed(auth()->id())->sum('earning_net_user');
        // Last Month
        $stat_revenue_last_month = Transactions::whereBetween('created_at', [
            Carbon::now()->startOfMonth()->subMonth(),
            Carbon::now()->subMonth()->endOfMonth(),
        ])->whereApproved('1')->whereSubscribed(auth()->id())->sum('earning_net_user');
        $label = implode(',', $monthsData);
        $data = implode(',', $earningNetUserSum);
        $response = [
            'success' => true,
            'data' => [
                'earningNetUser' => $earningNetUser,
                'subscriptionsActive' => $subscriptionsActive,
                'label' => $label,
                'data' => $data,
                'month' => $monthFormat,
                'stat_revenue_today' => $stat_revenue_today,
                'stat_revenue_yesterday' => $stat_revenue_yesterday,
                'stat_revenue_week' => $stat_revenue_week,
                'stat_revenue_last_week' => $stat_revenue_last_week,
                'stat_revenue_month' => $stat_revenue_month,
                'stat_revenue_last_month' => $stat_revenue_last_month
            ],
            'message' => 'User Dashboard.',
        ];
        return response()->json($response , 200);
//        return view('users.dashboard', [
//            'earningNetUser' => $earningNetUser,
//            'subscriptionsActive' => $subscriptionsActive,
//            'label' => $label,
//            'data' => $data,
//            'month' => $monthFormat,
//            'stat_revenue_today' => $stat_revenue_today,
//            'stat_revenue_yesterday' => $stat_revenue_yesterday,
//            'stat_revenue_week' => $stat_revenue_week,
//            'stat_revenue_last_week' => $stat_revenue_last_week,
//            'stat_revenue_month' => $stat_revenue_month,
//            'stat_revenue_last_month' => $stat_revenue_last_month
//        ]);
    }
    public function ajaxNotifications()
    {
        if (request()->ajax()) {
            // Logout user suspended
            if (auth()->user()->status == 'suspended' || ! auth()->check()) {
                auth()->logout();
                $response = [
                    'success' => false,
                    'data' => null,
                    'message' => 'Error Occurred.',
                ];
                return response()->json($response , 404);
//                return response()->json([
//                    'error' => true,
//                ]);
            }
            // Notifications
            $notifications_count = auth()->user()->notifications()->where('status', '0')->count();
            // Messages
            $messages_count = auth()->user()->messagesInbox();
            $response = [
                'success' => true,
                'data' => [
                    'messages' => $messages_count,
                    'notifications' => $notifications_count
                ],
                'message' => 'Ajax Notification.',
            ];
            return response()->json($response , 200);
//            return response()->json([
//                'messages' => $messages_count,
//                'notifications' => $notifications_count
//            ]);
        } else {
            $response = [
                'success' => false,
                'data' => null,
                'message' => 'Error Occurred.',
            ];
            return response()->json($response , 400);
//            return response()->json(['error' => 1]);
        }
    }
    public function settingsPage()
    {
        $genders = explode(',', $this->settings->genders);
        $categories = explode(',', auth()->user()->categories_id);
        $response = [
            'success' => true,
            'data' => [
                'genders' => $genders,
                'categories' => $categories
            ],
            'message' => 'Setting Page.',
        ];
        return response()->json($response , 200);
//        return view('users.edit_my_page', [
//            'genders' => $genders,
//            'categories' => $categories
//        ]);
    }
    public function privacySecurity()
    {
        $sessions = \DB::table('sessions')
            ->where('user_id', auth()->id())
            ->orderBy('id', 'DESC')
            ->first();
        $response = [
            'success' => true,
            'data' => [
                'sessions' => $sessions,
                'current_session_id' => \Session::getId(),
            ],
            'message' => 'Privacy Security Page.',
        ];
        return response()->json($response , 200);
//        return view('users.privacy_security')
//            ->with('sessions', $sessions)
//            ->with('current_session_id', \Session::getId());
    }
    public function verifyAccount()
    {
        $response = [
            'success' => true,
            'data' => null,
            'message' => 'Varify Account Page View.',
        ];
        return response()->json($response , 200);
//        return view('users.verify_account');
    }
    public function notifications()
    {
        // Notifications
        $notifications = DB::table('notifications')
            ->select(DB::raw('
        notifications.id id_noty,
        notifications.type,
        notifications.target,
        notifications.created_at,
        users.id userId,
        users.username,
        users.hide_name,
        users.name,
        users.avatar,
        updates.id,
        updates.description,
        U2.username usernameAuthor,
        messages.message,
        messages.to_user_id userDestination,
        products.name productName
        '))
            ->leftjoin('users', 'users.id', '=', DB::raw('notifications.author'))
            ->leftjoin('updates', 'updates.id', '=', DB::raw('notifications.target'))
            ->leftjoin('messages', 'messages.id', '=', DB::raw('notifications.target'))
            ->leftjoin('users AS U2', 'U2.id', '=', DB::raw('updates.user_id'))
            ->leftjoin('comments', 'comments.updates_id', '=', DB::raw('notifications.target
        AND comments.user_id = users.id
        AND comments.updates_id = updates.id'))
            ->leftjoin('products', 'products.id', '=', DB::raw('notifications.target'))
            ->where('notifications.destination', '=',  auth()->id())
            ->where('users.status', '=',  'active')
            ->groupBy('notifications.id')
            ->orderBy('notifications.id', 'DESC')
            ->paginate(20);
        // Mark seen Notification
        $getNotifications = Notifications::where('destination', auth()->id())->where('status', '0');
        $getNotifications->count() > 0 ? $getNotifications->update([
            'status' => '1'
        ]) : null;
        $response = [
            'success' => true,
            'data' => [
                'notifications' => $notifications,
            ],
            'message' => 'Notification Data.',
        ];
        return response()->json($response , 200);
//        return view('users.notifications', ['notifications' => $notifications]);
    }
    public function password()
    {
        $response = [
            'success' => true,
            'data' => null,
            'message' => 'Password Page View.',
        ];
        return response()->json($response , 200);
//        return view('users.password');
    }
    public function mySubscribers()
    {
        $subscriptions = auth()->user()->mySubscriptions()->orderBy('id','desc')->paginate(20);
        $response = [
            'success' => true,
            'data' => [
                'subscribers' => $subscriptions,
            ],
            'message' => 'Subscribers Data.',
        ];
        return response()->json($response , 200);
//        return view('users.my_subscribers')->withSubscriptions($subscriptions);
    }
    public function mySubscriptions()
    {
        $subscriptions = auth()->user()->userSubscriptions()->orderBy('id','desc')->paginate(20);
        $response = [
            'success' => true,
            'data' => [
                'subscriptions' => $subscriptions,
            ],
            'message' => 'Subscriptions Data.',
        ];
        return response()->json($response , 200);
//        return view('users.my_subscriptions')->withSubscriptions($subscriptions);
    }
    public function myPayments()
    {
        if (request()->is('my/payments')) {
            $transactions = auth()->user()->myPayments()->orderBy('id','desc')->paginate(20);
        } elseif (request()->is('my/payments/received')) {
            $transactions = auth()->user()->myPaymentsReceived()->orderBy('id','desc')->paginate(20);
        } else {
            $response = [
                'success' => false,
                'data' => null,
                'message' => 'Error Occurred.',
            ];
            return response()->json($response , 404);
//            abort(404);
        }
        $response = [
            'success' => true,
            'data' => [
                'transactions' => $transactions,
            ],
            'message' => 'Transactions Data.',
        ];
        return response()->json($response , 200);
//        return view('users.my_payments')->withTransactions($transactions);
    }
    public function invoice($id)
    {
        $data = Transactions::whereId($id)
            ->where('user_id', auth()->id())
            ->whereApproved('1')
            ->firstOrFail();
        $taxes = TaxRates::whereIn('id', collect(explode('_', $data->taxes)))->get();
        $total = $data->amount + ($data->amount * $taxes->sum('percentage') / 100);
        $response = [
            'success' => true,
            'data' => [
                'invoices' =>$data,
                'taxes' => $taxes,
                'total' => $total
            ],
            'message' => 'invoices Data.',
        ];
        return response()->json($response , 200);
//        return view('users.invoice')->with([
//            'data' =>$data,
//            'taxes' => $taxes,
//            'total' => $total
//        ]);
    }
    public function payoutMethod()
    {
        $stripeConnectCountries = explode(',', $this->settings->stripe_connect_countries);
        $response = [
            'success' => true,
            'data' => [
                'stripe_Connect_Countries' => $stripeConnectCountries,
            ],
            'message' => 'PayOut Methods Data.',
        ];
        return response()->json($response , 200);
//        return view('users.payout_method')->withStripeConnectCountries($stripeConnectCountries);
    }
    public function withdrawals()
    {
        $withdrawals = auth()->user()->withdrawals()->orderBy('id','desc')->paginate(20);
        $response = [
            'success' => true,
            'data' => [
                'withdrawals' => $withdrawals,
            ],
            'message' => 'Withdrawals Data.',
        ];
        return response()->json($response , 200);
//        return view('users.withdrawals')->withWithdrawals($withdrawals);
    }
    public function formAddUpdatePaymentCard()
    {
        $payment = PaymentGateways::whereName('Stripe')->whereEnabled(1)->firstOrFail();
        \Stripe\Stripe::setApiKey($payment->key_secret);
        $response = [
            'success' => true,
            'data' => [
                'intent' => auth()->user()->createSetupIntent(),
                'key' => $payment->key
            ],
            'message' => 'Payment Gateway  Data.',
        ];
        return response()->json($response , 200);
//        return view('users.add_payment_card', [
//            'intent' => auth()->user()->createSetupIntent(),
//            'key' => $payment->key
//        ]);
    }
    public function myBookmarks()
    {
        $bookmarks = auth()->user()->bookmarks()->orderBy('bookmarks.id','desc')->paginate($this->settings->number_posts_show);
        $users = $this->userExplore();
        $response = [
            'success' => true,
            'data' => [
                'bookmarks' => $bookmarks,
                'users' => $users
            ],
            'message' => 'Bookmarks Data.',
        ];
        return response()->json($response , 200);
//        return view('users.bookmarks', ['updates' => $bookmarks, 'users' => $users]);
    }
    public function myPurchases()
    {
        $purchases = auth()->user()->payPerView()->orderBy('pay_per_views.id','desc')->paginate($this->settings->number_posts_show);
        $users = $this->userExplore();
        $response = [
            'success' => true,
            'data' => [
                'purchases' => $purchases,
                'users' => $users
            ],
            'message' => 'Purchases Data.',
        ];
        return response()->json($response , 200);
//        return view('users.my-purchases', [
//            'updates' => $purchases,
//            'users' => $users
//        ]);
    }
    public function ajaxMyPurchases()
    {
        $skip = $this->request->input('skip');
        $total = $this->request->input('total');
        $data = auth()->user()->payPerView()->orderBy('pay_per_views.id','desc')->skip($skip)->take($this->settings->number_posts_show)->get();
        $counterPosts = ($total - $this->settings->number_posts_show - $skip);
        $response = [
            'success' => true,
            'data' => [
                'purchases' => $data,
                'ajaxRequest' => true,
                'counterPosts' => $counterPosts,
                'total' => $total
            ],
            'message' => 'Purchases Data.',
        ];
        return response()->json($response , 200);
//        return view('includes.updates',
//            ['updates' => $data,
//                'ajaxRequest' => true,
//                'counterPosts' => $counterPosts,
//                'total' => $total
//            ]
//        )->render();
    }
    public function downloadFile($id)
    {
        $post = Updates::findOrFail($id);
        $checkUserSubscription = auth()->user()->checkSubscription($post->user());
        if (! $checkUserSubscription
            && ! auth()->user()->payPerView()->where('updates_id', $post->id)->first()
            && $post->user()->id != auth()->id()
            || $checkUserSubscription
            && $post->price != 0.00
            && $checkUserSubscription->free == 'yes'
            && ! auth()->user()->payPerView()->where('updates_id', $post->id)->first()
        ) {
            $response = [
                'success' => false,
                'data' => null,
                'message' => 'Error Occurred.',
            ];
            return response()->json($response , 404);
//            abort(404);
        }
        $media = Media::whereUpdatesId($post->id)->where('file', '<>', '')->firstOrFail();
        $pathFile = config('path.files').$media->file;
        $headers = [
            'Content-Type:' => 'application/x-zip-compressed',
            'Cache-Control' => 'no-cache, no-store, must-revalidate',
            'Pragma' => 'no-cache',
            'Expires' => '0'
        ];
        $response = [
            'success' => true,
            'data' => [
                'header' => $headers,
                'path' => $pathFile,
                'file_name' => $media->file_name.' '.__('general.by').' @'.$post->user()->username.'.zip',
            ],
            'message' => 'Download File.',
        ];
        return response()->json($response , 200);
//        return Storage::download($pathFile, $media->file_name.' '.__('general.by').' @'.$post->user()->username.'.zip', $headers);
    }
    public function invoiceDeposits($id)
    {
        $data = Deposits::whereId($id)->whereUserId(auth()->id())->whereStatus('active')->firstOrFail();
        $taxes = TaxRates::whereIn('id', collect(explode('_', $data->taxes)))->get();
        $totalTaxes = ($data->amount * $taxes->sum('percentage') / 100);
        $totalAmount = ($data->amount + $data->transaction_fee + $totalTaxes);
        $response = [
            'success' => true,
            'data' => [
                'invoice_Deposits' => $data,
                'amount' => $data->amount,
                'percentageApplied' => $data->percentage_applied,
                'transactionFee' => $data->transaction_fee,
                'totalAmount' => $totalAmount,
                'taxes' => $taxes
            ],
            'message' => 'Invoice Deposits Data.',
        ];
        return response()->json($response , 200);
//        return view('users.invoice-deposits', [
//            'data' => $data,
//            'amount' => $data->amount,
//            'percentageApplied' => $data->percentage_applied,
//            'transactionFee' => $data->transaction_fee,
//            'totalAmount' => $totalAmount,
//            'taxes' => $taxes
//        ]);
    }
    public function myCards()
    {
        $payment = PaymentGateways::whereName('Stripe')->whereEnabled(1)->first();
        $paystackPayment = PaymentGateways::whereName('Paystack')->whereEnabled(1)->first();
        if (! $payment && ! $paystackPayment) {
            $response = [
                'success' => false,
                'data' => null,
                'message' => 'Error Occurred.',
            ];
            return response()->json($response , 404);
//            abort(404);
        }
        if (auth()->user()->stripe_id != '' && auth()->user()->pm_type != '' && isset($payment->key_secret)) {
            $stripe = new \Stripe\StripeClient($payment->key_secret);
            $response = $stripe->paymentMethods->all([
                'customer' => auth()->user()->stripe_id,
                'type' => 'card',
            ]);
            $expiration = $response->data[0]->card->exp_month.'/'.$response->data[0]->card->exp_year;
        }
        $chargeAmountPaystack = ['NGN' => '50.00', 'GHS' => '0.10', 'ZAR' => '1', 'USD' => 0.20];
        if (array_key_exists($this->settings->currency_code, $chargeAmountPaystack)) {
            $chargeAmountPaystack = $chargeAmountPaystack[$this->settings->currency_code];
        } else {
            $chargeAmountPaystack = 0;
        }
        $response = [
            'success' => true,
            'data' => [
                'key_secret' => $payment->key_secret ?? null,
                'expiration' => $expiration ?? null,
                'paystackPayment' => $paystackPayment,
                'chargeAmountPaystack' => $chargeAmountPaystack
            ],
            'message' => 'Cards Data.',
        ];
        return response()->json($response , 200);
//        return view('users.my_cards',[
//            'key_secret' => $payment->key_secret ?? null,
//            'expiration' => $expiration ?? null,
//            'paystackPayment' => $paystackPayment,
//            'chargeAmountPaystack' => $chargeAmountPaystack
//        ]);
    }
    public function restrictions()
    {
        $restrictions = auth()->user()->restrictions()->orderBy('id', 'desc')->paginate(15);
        $response = [
            'success' => true,
            'data' => [
                'restrictions' => $restrictions
            ],
            'message' => 'Restrictions Data.',
        ];
        return response()->json($response , 200);
//        return view('users.restricted_users')->withRestrictions($restrictions)
    }
    public function profile($slug, $media = null)
    {
        $media = request('media');
        $mediaTitle = null;
        $sortPostByTypeMedia = null;
        if (isset($media)) {
            $mediaTitle = trans('general.'.$media.'').' - ';
            $sortPostByTypeMedia = '&media='.$media;
            $media = '/'.$media;
        }
        // All Payments
        $allPayment = PaymentGateways::where('enabled', '1')->whereSubscription('yes')->get();
        // Stripe Key
        $_stripe = PaymentGateways::whereName('Stripe')->where('enabled', '1')->select('key')->first();
        $user = User::where('username','=', $slug)->whereStatus('active')->firstOrFail();
        if ($media && $user->verified_id != 'yes') {
            $response = [
                'success' => false,
                'data' => null,
                'message' => 'Error Occurred.',
            ];
            return response()->json($response , 404);
//            abort(404);
        }
        // Hidden Profile Admin
        if (auth()->check() && $this->settings->hide_admin_profile == 'on'
            && $user->id == 1
            && auth()->id() != 1
        ) {
            $response = [
                'success' => false,
                'data' => null,
                'message' => 'Error Occurred.',
            ];
            return response()->json($response , 404);
//            abort(404);
        } elseif (auth()->guest()
            && $this->settings->hide_admin_profile == 'on'
            && $user->id == 1
        ) {
            $response = [
                'success' => false,
                'data' => null,
                'message' => 'Error Occurred.',
            ];
            return response()->json($response , 404);
//            abort(404);
        }
        // Hidden Profile Blocked Countries
        if (in_array(Helper::userCountry(), $user->blockedCountries())
            && auth()->check()
            && auth()->user()->permission != 'all'
            && auth()->id() != $user->id
            || auth()->guest()
            && in_array(Helper::userCountry(), $user->blockedCountries())
        ) {
            $response = [
                'success' => false,
                'data' => null,
                'message' => 'Error Occurred.',
            ];
            return response()->json($response , 404);
//            abort(404);
        }
        if (isset($media)) {
            $query = $user->media();
        } else {
            $query = $user->updates()->whereFixedPost('0');
        }
        //=== Photos
        $query->when(request('media') == 'photos', function($q) {
            $q->where('media.image', '<>', '');
        });
        //=== Videos
        $query->when(request('media') == 'videos', function($q) use($user) {
            $q->where('media.video', '<>', '')
                ->where(function ($query) {
                    $query->when(request('sort') == 'unlockable', function($q) {
                        $q->where('updates.price', '<>', 0.00);
                    });
                    $query->when(request('sort') == 'free', function($q) {
                        $q->where('updates.locked', 'no');
                    });
                })
                ->orWhere('media.video_embed', '<>', '')
                ->where('media.user_id', $user->id);
        });
        //=== Audio
        $query->when(request('media') == 'audio', function($q) {
            $q->where('media.music', '<>', '');
        });
        //=== Files
        $query->when(request('media') == 'files', function($q) {
            $q->where('media.file', '<>', '');
        });
        // Sort by older
        $query->when(request('sort') == 'oldest', function($q) {
            $q->orderBy('updates.id', 'asc');
        });
        // Sort by unlockable
        $query->when(request('sort') == 'unlockable', function($q) {
            $q->where('updates.price', '<>', 0.00);
        });
        // Sort by free
        $query->when(request('sort') == 'free', function($q) {
            $q->where('updates.locked', 'no');
        });
        $updates = $query->orderBy('updates.id','desc')
            ->groupBy('updates.id')
            ->paginate($this->settings->number_posts_show);
        // Check if subscription exists
        if (auth()->check()) {
            $checkSubscription = auth()->user()->checkSubscription($user);
            if ($checkSubscription) {
                // Get Payment gateway the subscription
                $paymentGatewaySubscription = Transactions::whereSubscriptionsId($checkSubscription->id)->first();
            }
            // Check Payment Incomplete
            $paymentIncomplete = auth()->user()
                ->userSubscriptions()
                ->whereIn('stripe_price', $user->plans()->pluck('name'))
                ->whereStripeStatus('incomplete')
                ->first();
        }
        //<<<-- * Redirect the user real name * -->>>
        $uri = request()->path();
        $uriCanonical = $user->username.$media;
        if ($uri != $uriCanonical) {
            return redirect($uriCanonical);
        }
        // Find post pinned
        $findPostPinned = $user->updates()->whereFixedPost('1')->paginate($this->settings->number_posts_show);
        // Count all likes
        $likeCount = $user->likesCount();
        // Categories
        $categories = explode(',', $user->categories_id);
        // Subscriptions Active
        $subscriptionsActive = $user->totalSubscriptionsActive();
        // User Plans
        $plans = $user->plans()
            ->where('interval', '<>', 'monthly')
            ->whereStatus('1')
            ->get();
        // User Plan Monthly Active
        $userPlanMonthlyActive = $user->planActive();
        // Total Items of User
        $userProducts = $user->products()->whereStatus('1');
        // Filter by oldest
        $userProducts->when(request('sort') == 'oldest', function($q) {
            $q->orderBy('id', 'asc');
        });
        // Filter by lowest price
        $userProducts->when(request('sort') == 'priceMin', function($q) {
            $q->orderBy('price', 'asc');
        });
        // Filter by Highest price
        $userProducts->when(request('sort') == 'priceMax', function($q) {
            $q->orderBy('price', 'desc');
        });
        // Filter by Digital Products
        $userProducts->when(request('sort') == 'digital', function($q) {
            $q->where('type', 'digital');
        });
        // Filter by Custom Content
        $userProducts->when(request('sort') == 'custom', function($q) {
            $q->where('type', 'custom');
        });
        $userProducts = $userProducts->orderBy('id', 'desc')
            ->paginate(15);
        $response = [
            'success' => true,
            'data' => [
                'user' => $user,
                'updates' => $updates,
                'findPostPinned' => $findPostPinned,
                '_stripe' => $_stripe,
                'checkSubscription' => $checkSubscription ?? null,
                'media' => $media,
                'mediaTitle' => $mediaTitle,
                'sortPostByTypeMedia' => $sortPostByTypeMedia,
                'allPayment' => $allPayment,
                'paymentIncomplete' => $paymentIncomplete ?? null,
                'likeCount' => $likeCount,
                'categories' => $categories,
                'paymentGatewaySubscription' => $paymentGatewaySubscription->payment_gateway ?? null,
                'subscriptionsActive' => $subscriptionsActive,
                'plans' => $plans,
                'userPlanMonthlyActive' => $userPlanMonthlyActive ?? null,
                'userProducts' => $userProducts
            ],
            'message' => 'Profile Data.',
        ];
        return response()->json($response , 200);
//        return view('users.profile',[
//            'user' => $user,
//            'updates' => $updates,
//            'findPostPinned' => $findPostPinned,
//            '_stripe' => $_stripe,
//            'checkSubscription' => $checkSubscription ?? null,
//            'media' => $media,
//            'mediaTitle' => $mediaTitle,
//            'sortPostByTypeMedia' => $sortPostByTypeMedia,
//            'allPayment' => $allPayment,
//            'paymentIncomplete' => $paymentIncomplete ?? null,
//            'likeCount' => $likeCount,
//            'categories' => $categories,
//            'paymentGatewaySubscription' => $paymentGatewaySubscription->payment_gateway ?? null,
//            'subscriptionsActive' => $subscriptionsActive,
//            'plans' => $plans,
//            'userPlanMonthlyActive' => $userPlanMonthlyActive ?? null,
//            'userProducts' => $userProducts
//        ]);
    }
    public function postDetail($slug, $id)
    {
        $user    = User::where( 'username','=', $slug )->where('status','active')->firstOrFail();
        $updates = Updates::whereUserId($user->id)
            ->whereId($id)
            ->where('status', '<>', 'encode')
            ->orderBy('id','desc')
            ->paginate(1);
        $updateCount = $updates->count();
        // Check the status of the post
        if (auth()->check() && $updateCount != 0 && $updates[0]->user_id != auth()->id()
            && $updates[0]->status == 'pending'
            && auth()->user()->role != 'admin'
        ) {
            $response = [
                'success' => false,
                'data' => null,
                'message' => 'Error Occurred.',
            ];
            return response()->json($response , 404);
//            abort(404);
        } elseif (auth()->guest() && $updateCount != 0 && $updates[0]->status == 'pending') {
            $response = [
                'success' => false,
                'data' => null,
                'message' => 'Error Occurred.',
            ];
            return response()->json($response , 404);
//            abort(404);
        }
        // Hidden Profile Blocked Countries
        if (in_array(Helper::userCountry(), $user->blockedCountries())
            && auth()->check()
            && auth()->user()->permission != 'all'
            && auth()->id() != $user->id
            || auth()->guest()
            && in_array(Helper::userCountry(), $user->blockedCountries())
        ) {
            $response = [
                'success' => false,
                'data' => null,
                'message' => 'Error Occurred.',
            ];
            return response()->json($response , 404);
//            abort(404);
        }
        $users = $this->userExplore();
        if ($user->status == 'suspended' || $updateCount == 0) {
            $response = [
                'success' => false,
                'data' => null,
                'message' => 'Error Occurred.',
            ];
            return response()->json($response , 404);
//            abort(404);
        }
        //<<<-- * Redirect the user real name * -->>>
        $uri = request()->path();
        $uriCanonical = $user->username.'/post/'.$updates[0]->id;
        if( $uri != $uriCanonical ) {
            $response = [
                'success' => true,
                'data' => [
                    'redirect_url' => $uriCanonical,
                ],
                'message' => 'Redirect Url.',
            ];
            return response()->json($response , 200);
//            return redirect($uriCanonical);
        }
        $response = [
            'success' => true,
            'data' => [
                'updates' => $updates,
                'inPostDetail' => true,
                'users' => $users
            ],
            'message' => 'Post Detail.',
        ];
        return response()->json($response , 200);
//        return view('users.post-detail',
//            ['user' => $user,
//                'updates' => $updates,
//                'inPostDetail' => true,
//                'users' => $users
//            ]
//        );
    }
    public function myPosts()
    {
        if (auth()->user()->verified_id != 'yes') {
            $response = [
                'success' => false,
                'data' => null,
                'message' => 'Error Occurred.',
            ];
            return response()->json($response , 404);
//            abort(404);
        }
        $posts = Updates::whereUserId(auth()->id())
            ->where('status', '<>', 'encode')
            ->orderBy('id', 'desc')
            ->paginate(20);
        if ($posts->currentPage() > $posts->lastPage()) {
            $response = [
                'success' => false,
                'data' => null,
                'message' => 'Error Occurred.',
            ];
            return response()->json($response , 404);
//            abort(404);
        }
        $response = [
            'success' => true,
            'data' => [
                'posts' => $posts
            ],
            'message' => 'Posts Data.',
        ];
        return response()->json($response , 200);
//        return view('users.my_posts')->withPosts($posts);
    }
    public function blockCountries()
    {
        if (auth()->user()->verified_id != 'yes') {
            $response = [
                'success' => false,
                'data' => null,
                'message' => 'Error Occurred.',
            ];
            return response()->json($response , 404);
//            abort(404);
        }
        $response = [
            'success' => true,
            'data' => null,
            'message' => 'Block Countries Data.',
        ];
        return response()->json($response , 200);
//        return view('users.block_countries');
    }
    public function myReferrals()
    {
        $transactions = ReferralTransactions::whereReferredBy(auth()->id())
            ->orderBy('id', 'desc')
            ->paginate(20);
        $response = [
            'success' => true,
            'data' => [
                'transactions' => $transactions
            ],
            'message' => 'Transactions Data.',
        ];
        return response()->json($response , 200);
//        return view('users.referrals', ['transactions' => $transactions]);
    }
    public function purchasedItems()
    {
        $purchases = auth()->user()->purchasedItems()->orderBy('id', 'desc')->paginate(10);
        $response = [
            'success' => true,
            'data' => [
                'purchases' => $purchases
            ],
            'message' => 'Purchases Data.',
        ];
        return response()->json($response , 200);
//        return view('users.purchased_items')->withPurchases($purchases);
    }
    public function mySales()
    {
        if (auth()->user()->verified_id != 'yes') {
            $response = [
                'success' => false,
                'data' => null,
                'message' => 'Error Occurred.',
            ];
            return response()->json($response , 404);
//            abort(404);
        }
        $sales = auth()->user()->sales();
        // Sort by oldest
        $sales->when(request('sort') == 'oldest', function($q) {
            $q->orderBy('id', 'asc');
        });
        // Sort by pending
        $sales->when(request('sort') == 'pending', function($q) {
            $q->where('delivery_status', 'pending');
        });
        $sales = $sales->orderBy('id', 'desc')->paginate(10);
        $response = [
            'success' => true,
            'data' => [
                'sales' => $sales
            ],
            'message' => 'Sales Data.',
        ];
        return response()->json($response , 200);
//        return view('users.my-sales')->withSales($sales);
    }
    public function myProducts()
    {
        if (auth()->user()->verified_id != 'yes') {
            $response = [
                'success' => false,
                'data' => null,
                'message' => 'Error Occurred.',
            ];
            return response()->json($response , 404);
//            abort(404);
        }
        $products = auth()->user()->products()
            ->with('purchases')
            ->orderBy('id', 'desc')->paginate(20);
        if ($products->currentPage() > $products->lastPage()) {
            $response = [
                'success' => false,
                'data' => null,
                'message' => 'Error Occurred.',
            ];
            return response()->json($response , 404);
//            abort(404);
        }
        $response = [
            'success' => true,
            'data' => [
                'products' => $products
            ],
            'message' => 'Products Data.',
        ];
        return response()->json($response , 200);
//        return view('users.my_products')->withProducts($products);
    }
    public function mentions()
    {
        $users = User::whereStatus('active')
            ->where('username', 'LIKE', '%'.$this->request->filter.'%')
            ->orderBy('verified_id', 'asc')
            ->take(5)
            ->get();
        foreach ($users as $user) {
            $verified = $user->verified_id == 'yes' ? ' <i class="bi bi-patch-check-fill verified"></i>' : null;
            $data[] = [
                'name' => $user->hide_name == 'yes' ? $user->username.$verified : $user->name.$verified,
                'username' => $user->username,
                "avatar" => Helper::getFile(config('path.avatar').$user->avatar)
            ];
        }
        $response = [
            'success' => true,
            'data' => [
                'tags' => $data ?? null
            ],
            'message' => 'Tags Data.',
        ];
        return response()->json($response , 200);
//        return response()->json([
//            'tags' => $data ?? null
//        ], 200);
    }
}
